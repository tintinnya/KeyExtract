# WhatsApp Crypt12 Database Decrypter
Decrypts WhatsApp msgstore.db.crypt12 files.

###### Usage:

              python decrypt12.py key msgstore.db.crypt12 msgstore.db   
              java -jar decrypt12.jar key msgstore.db.crypt12 msgstore.db  
  
###### Requirements:
  
 Python 2.x or 3.x with pycrypto and pycryptodome packages installed or Java.
  
###### Credits:
 Author: TripCode
